import java.sql.*;
import java.util.*;

public class ProductCRUD {
    static final String URL = "jdbc:mysql://localhost:3306/testdb";
    static final String USER = "root";
    static final String PASSWORD = "yourpassword";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(URL, USER, PASSWORD);

            while (true) {
                System.out.println("\n1. Insert\n2. Display\n3. Update\n4. Delete\n5. Exit");
                int choice = sc.nextInt();

                if (choice == 1) {
                    System.out.print("Enter Product Name: ");
                    String name = sc.next();
                    System.out.print("Enter Price: ");
                    double price = sc.nextDouble();

                    PreparedStatement ps = con.prepareStatement("INSERT INTO product(name, price) VALUES(?, ?)");
                    ps.setString(1, name);
                    ps.setDouble(2, price);
                    ps.executeUpdate();
                    System.out.println("Product Inserted!");
                } else if (choice == 2) {
                    Statement st = con.createStatement();
                    ResultSet rs = st.executeQuery("SELECT * FROM product");
                    while (rs.next()) {
                        System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getDouble(3));
                    }
                } else if (choice == 3) {
                    System.out.print("Enter Product ID to Update: ");
                    int id = sc.nextInt();
                    System.out.print("Enter New Price: ");
                    double price = sc.nextDouble();

                    PreparedStatement ps = con.prepareStatement("UPDATE product SET price=? WHERE id=?");
                    ps.setDouble(1, price);
                    ps.setInt(2, id);
                    ps.executeUpdate();
                    System.out.println("Product Updated!");
                } else if (choice == 4) {
                    System.out.print("Enter Product ID to Delete: ");
                    int id = sc.nextInt();
                    PreparedStatement ps = con.prepareStatement("DELETE FROM product WHERE id=?");
                    ps.setInt(1, id);
                    ps.executeUpdate();
                    System.out.println("Product Deleted!");
                } else {
                    con.close();
                    System.out.println("Connection Closed.");
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        sc.close();
    }
}
