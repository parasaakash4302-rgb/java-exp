package patc_c;
import java.util.*;

public class StudentController {
    public static void main(String[] args) {
        try {
            StudentDAO dao = new StudentDAO();
            try (Scanner sc = new Scanner(System.in)) {
                while (true) {
                    System.out.println("\n1. Add Student\n2. View Students\n3. Exit");
                    int ch = sc.nextInt();

                    if (ch == 1) {
                        System.out.print("Enter ID: ");
                        int id = sc.nextInt();
                        System.out.print("Enter Name: ");
                        String name = sc.next();
                        System.out.print("Enter Age: ");
                        int age = sc.nextInt();

                        dao.addStudent(new Student(id, name, age));
                        System.out.println("Student Added!");
                    } else if (ch == 2) {
                        List<Student> list = dao.getAllStudents();
                        for (Student s : list)
                            System.out.println(s.getId() + " " + s.getName() + " " + s.getAge());
                    } else break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
